<?php
  include('config.php');
if(isset($_POST['submit'])){

 $firstname=$_POST['firstname'];
 $lastname=$_POST['lastname'];
 $email=$_POST['email'];
 $country=$_POST['country'];


 $insertquery="INSERT INTO `mytable`(`firstname`, `lastname`, `email`, `country`) VALUES ('$firstname','$lastname','$email','$country')";

$res=mysqli_query($con, $insertquery);

 if($res){
     echo "Form data insert successfully";

     header('Location: http://localhost/web1/webd.html');


     
    }else{     
        
        echo "do not inserted"; 
}

 }
?>