<?php


$con=mysqli_connect("localhost","root","","cord");

if($con){
    
}



?>