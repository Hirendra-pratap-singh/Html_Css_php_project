

var express = require('express');
var app = express();
var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended : true}))

app.get('/index.html/contact ', function(req,res){
    res.sendFile(__dirname+'/index.html');
});

app.post('/index.html/contact', function(req,res){
  console.log("req.body");
});

app.listen(5000);